RMS Module for VCOS Project
